static void focusmaster(const Arg *arg);

