static int width_pwrl_tags(Bar *bar, BarArg *a);
static int draw_pwrl_tags(Bar *bar, BarArg *a);
static int click_pwrl_tags(Bar *bar, Arg *arg, BarArg *a);

