static void bstack(Monitor *m);

