static void gaplessgrid(Monitor *m);

